/*! elementor - v3.31.0 - 11-08-2025 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!*******************************************************!*\
  !*** ../core/editor/loader/v1/js/editor-loader-v1.js ***!
  \*******************************************************/


window.elementor.start();
/******/ })()
;
//# sourceMappingURL=editor-loader-v1.js.map